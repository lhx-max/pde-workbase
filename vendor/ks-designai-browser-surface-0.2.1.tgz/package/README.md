# @ks-designai/browser-surface

The standalone browser app's full UI as an embeddable React component, plus the
pre-existing canvas helpers (`launchFromSearch`, `acceptOpenEditorCard`,
`canvasFileApi`).

## Install & mount

```ts
import { BrowserAppSurface } from '@ks-designai/browser-surface';
import '@ks-designai/browser-surface/styles.css';

<BrowserAppSurface
  instanceId={browserInstanceId}          // the browser app's own project id
  transport={{
    baseUrl: '/api/browser-app',          // or 'https://browser.example.com'
    fetch: authedFetch,                   // optional: app-API requests go through it
    resourceUrl: url => signed(url),      // optional: only ever sees app-API URLs
  }}
  onError={err => report(err)}
/>
```

`baseUrl` is the prefix of the **browser service API** — the surface appends
its own `/api/projects`, `/api/browser-preferences`, `/api/asset-library`, …
paths onto it. It is not the generic `/api/apps/browser` protocol root.
`baseUrl` must be `''` (same origin, dev), a single-slash path prefix
(`/api/browser-app`), or an HTTPS origin (HTTP only on loopback). Userinfo,
query, fragment, and protocol-relative forms are rejected.

## Contract

- `instanceId` is the browser app's own project — never a canvas `projectId`.
- The component never reads `location.search`, never rewrites `history` or the
  host `document`; overlays portal into a node inside the surface root.
- One live scope at a time: mounting a second surface with a different
  `(instanceId, transport)` scope throws — the host mounts only the active tab.
- Requests capture the transport at call time; preferences and other
  cross-instance caches reset on scope switch, so nothing from a previous
  tenant survives.
- Without the native host (`@bezier/host` window bridge) the web limitations
  hold: the collector panel reports itself unavailable and nothing fakes a
  successful capture. The component never starts Electron.
- External web requests never receive tenant credentials — app-API auth only
  ever flows through the injected `transport.fetch`.

## React

`react` and `react-dom` `18.3.1` are peers — they are never bundled.

## Web collector (0.2.0)

`CollectorAppSurface` is the embeddable project-scoped collector dashboard. Pass `instanceId`, `transport` and optional `extensionDownloadUrl`; import `styles.css`. The MV3 extension is a separate installable ZIP, not an npm UI component. A connection code authorizes only capture/status for one project and expires within 24 hours. The dashboard distinguishes authorization from an actual extension connection.

The backend requires `BROWSER_COLLECTOR_SIGNING_KEY` and `BROWSER_COLLECTOR_PUBLIC_BASE_URL`. Use HTTPS for deployment; a loopback endpoint is only a development proof even when storage uses real Appwrite. Formal MA registration, host authentication and deployed API acceptance remain separate gates.
