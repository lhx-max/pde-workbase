# Document Surface

Install from the company registry:

```sh
npm install @ks-designai/doc-surface@0.1.2 --registry=https://npm.corp.kuaishou.com/
```

Requires a single host React/ReactDOM 18.3.1 runtime. Import `@ks-designai/doc-surface/styles.css`, mount `DocumentEditorPane`, and inject the existing `DocDocumentApi` and real `DocMeta`. The package includes built JavaScript, declarations, editor CSS Modules and scoped styles. It does not start a backend or contain credentials. Source is extracted from the canvas Markdown document editor; see the repository README for provenance.

The host supplies authenticated readSnapshot/writeSnapshot adapters and real instance mapping. Preserve content revision and baseContent on writes; retain drafts on failure. An npm installation does not publish an App manifest or connect the remote MA tool runtime.
