# DesignAI Image · 独立生图 App

生图拥有独立后端、业务数据库和私有文件桶，保存原件、结果、配置、任务、编辑工程及回执；画布通过公开 API 保存布局、资源引用和认证预览。旧画布承载 profile 仅作为兼容实现保留，不是当前默认部署架构。

开发前读 [App 合同](docs/APP_CONTRACT.md)、[独立后端合同](docs/INDEPENDENT_BACKEND.md)；部署读 [部署手册](deployment/README.zh-CN.md)。仓库负责人及资源审批入口为李鹏；共同集成分支 main，日常从功能分支开发。构建、发布、正式宿主安装、Agent 调用及 staging 分别验收。

| 出口 | 用途 |
| --- | --- |
| `/react` | IndependentImageWorkspace、createIndependentImageHttpTransport；宿主提供 React 18.3.1 与可信请求能力，安装包含 CPU Worker 的运行资源 |
| `/app-backend` | 独立业务服务、存储、Provider 和精确 manifest；React-free |
| `designai-image-app-server` | 常驻 HTTP 服务，Appwrite 权威存储；缺配置拒绝启动 |
| `designai-image-app` | 调用同一后端的 CLI，读取、动作、任务、资源与回执，不另建本地库 |
| `/server`、旧卡片组件、designai-image-service | 画布承载/单用户模型执行兼容入口，不能用它们冒充独立服务或正式用户授权 |

完整编辑器 `editor/` 单独构建，见 [迁移记录](docs/FULL_CANVAS_MIGRATION.md)。不同前端不因同仓而自动统一身份、存储及运行配置。

```sh
# Node 24 / pnpm 10.33.2
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
npm pack --ignore-scripts --pack-destination /absolute/release-directory
docker build --platform linux/amd64 -f Dockerfile.backend -t designai-image-independent:release-candidate .
```

生产要求独立私有资源、最小权限服务身份、可信 MA authority、精确动作授权与逐调用者模型 adapter。不复用维护者 Cookie/设备授权，不把 MA SSO 直接用于模型。原件上限 30,000,000 字节，按 5,000,000 字节分块；恢复不自动重新派发付费任务。

模型及工具按运行时能力报告；GPU、分层/OCR、自动曲面等未配置时明确不可用。高清档 GPT 方图原生 2880×2880，Gemini 方图 4096×4096。构建和独立页面通过不代表正式 MA 安装或 Agent 自主调用已通过。

历史 0.8.0 画布承载说明完整保存在 [历史 README](docs/LEGACY_CANVAS_README.md) 和 [历史合同](docs/LEGACY_CANVAS_APP_CONTRACT.md)，其中的版本、资源与阶段描述不适用于当前独立部署。
