# 完整画布迁移 · 2026-10-22

用户明确选择将自己的完整画布迁入本图片 App 仓库，并保留原仓。目标开发分支 `migrate-full-canvas-20261022`，起点为 `codex/app-acceptance-20261021` 的 `aa29c317747d00b4dc0ea7eb69e4c95f4ca978d7`。不覆盖原验收分支，不直接合主分支。

来源：`git@git.corp.kuaishou.com:MarioDesign-FT/design-canvas.git`，提交 `c9aa156`（包含 master 已合入的完整画布和新协议准备）。仅迁移 Git 跟踪源码；不包含 node_modules、构建产物、用户数据、凭据、本机配置、旧部署目标文件和历史验收媒体。许可证与来源声明保留在 editor/LICENSE.txt、THIRD_PARTY_NOTICES.md、docs/移植依赖声明.md。

## 布局与入口

- 根 src/：同事已有图片卡片工具、生图、执行器、产物存储；根包公开入口不变。
- editor/excalidraw/：完整画布界面和绘图引擎适配。
- editor/packages/canvas-surface/：完整 DesignCanvas React 组件。
- editor/packages/canvas-storage/、functions/canvas-storage/：原保存适配器与函数实现，尚未接到同事的存储。
- editor/examples/：独立组件、双实例和协议打开示例。
- editor/scripts/dev-server.mjs：仅环回开发服务，含显式本地示例存储；不能作为正式后端。

完整画布与图片卡片是不同交付物。本次没有把完整编辑器偷偷替换成卡片组件，也没有删除同事已迁入的工具实现。后续共用工具的收敛需要单独确认，当前不得手工同步两套实现。

## 开发

根包继续 Node 24、pnpm 10.33.2，按原 pnpm-lock 安装；迁入模块使用自身 npm 锁文件，保持已有构建补丁的依赖版本。

```sh
npm run editor:install
npm run editor:check
npm run editor:build
npm run editor:test
npm run editor:dev
```

默认仅本机 `http://127.0.0.1:5178/excalidraw/component.html`；端口占用可 `CANVAS_PORT=5194 npm run editor:dev`。不会连接另一个 checkout。完整组件预览仅证明组件可运行，不代表云端保存。

打包：`npm run editor:pack`，产物 `editor/dist/mariodesign-canvas-surface-0.1.0.tgz`，仍导出 DesignCanvas/CanvasHandle 类型。根图片卡片包的 pnpm build/pack 不会把完整编辑器偷偷塞进其纯 server 入口。正式消费者安装该 tgz 并共享宿主 React 18.3.1。

## 数据与后端边界

原完整画布部分工具仍调用原 /api/tools/* 协议；同事 image.tool 的资源/授权/任务信封并不相同。需要显式适配后才能声称工具全部接通。源码迁移不携带模型密钥，不复用个人凭据，不调用付费模型验收。

原云示例中 designcanvasdev20261021、canvasdevtest 是历史开发目标。此迁移不在该项目新增数据，不将它当同事项目，也不为同事项目创建库或修改ACL。宿主需注入自身已验证的用户/业务空间/实例映射、资源读写及保存回传接口；原JWT方案不等于MA身份适配。

本次交付是同仓源码、可构建组件和实际预览；不是生产部署、完整工具后端迁移、正式MA注册或云保存切换。旧 docs 中的验收证据属于来源仓历史；未搬入的 verification 文件可回来源提交查看，不能当本分支复测结果。

依赖安装补充：公司镜像的 rollup@4.64.12 tarball 返回404；editor/.npmrc 对公共包使用 npm 官方源，仅 @codeflicker 使用公司源。锁文件版本和完整性不变。若本机 ~/.npm 缓存权限异常，可使用 `npm --prefix editor ci --cache /tmp/designai-editor-cache`，不修改全局缓存权限。

## 本分支验证结果

- Node24.19.0下完整画布 check:surface、check:storage、页面build、组件build通过。
- 完整画布73项测试通过；生产静态入口测试要求先build，首次未build的404已在构建后复测通过。
- 新目录开发服务5194实际打开；文字创建、撤销、重做通过；构建组件在5294独立预览正常。
- tgz在隔离消费者目录实际安装，公开类型检查通过；SHA-1 `0e927e76a56b48028ecd75c0e16f05574faf81c8`。未发布npm。
- 原图片根包typecheck失败：src/tool-result.ts引用src/artifacts/contract.js和types.js，但基线aa29c31未跟踪整个src/artifacts目录。此问题在迁移前已存在，未补造文件；根包build/packed消费者因此未标通过。
- 不依赖原design-canvas的node_modules或源码路径；没有运行真实模型或修改云数据，没有将上述本地检查计为云端验收。

## 2026-10-23 更新同步

用户指定同步到 codex/app-acceptance-20261021。以已集成的 main 9e83f95 为底，editor/ 更新至来源 design-canvas ac0807f 的增量。保留 editor 局部约定和根包现有实现；原仓验收记录仅为来源证据，不表示本仓已部署或获得服务凭据。四项依赖服务器资源的工具入口暂缓到二期。

同步复核：来源增量逐文件字节一致；editor 页面/组件构建、surface/storage 类型检查及111项测试通过；根图片包类型/构建、135项测试与打包通过。未改变根 src/ 接口；不包含原工作区未提交的角色工具改动。使用隔离工作树完成，未改动 main。
