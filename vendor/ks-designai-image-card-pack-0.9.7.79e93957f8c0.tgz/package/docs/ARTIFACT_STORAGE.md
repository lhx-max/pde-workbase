# 图片工具持久化合同 v1 · 2026-10-22

迁移进行中。代码和fixture通过不等于已挂载全部UI/Provider，验收记录以画布仓 docs/verification/image-tool-persistence-20261022 为准。

- `/artifact-contract`：纯DTO与校验器，manifest仅包含授权范围、源资源、参数与产物引用，不包含图片字节、大型分层/曲面数据。无React、Node/native依赖。
- `/artifact-store`：服务端ToolArtifactStore，注入云端journal、files、authorize三个端口。默认不提供本地存储。模型执行不在此服务内，恢复产物上传不会再次发起付费生成。
- Storage保存PNG/JPEG/WebP/SVG、蒙版、分层原件和编辑状态JSON、UV/mask曲面文件；小型manifest和job元数据由JSON journal持久化。编辑状态JSON通过editStateArtifactId关联。
- namespace/projectId必须由可信后端从宿主租户/业务空间/实例解析；actorId来自已验证用户，不得从浏览器透传身份。scope用于隔离，不充当授权凭据；每次读写和重放仍需authorize。
- begin按scope+actor+幂等键生成稳定执行ID，并核对请求摘要和工具参数。上传前保存不可变产物计划，逐件上传并保存staged回执，全部完成后才发布manifest。失败/取消保留原图、已跟踪上传和计划，不能标记成功。重放只接受相同产物摘要。
- 单文件30,000,000bytes，单批256MiB，1..128产物，manifest128KiB；大型可编辑结构落Storage文件。当前journal适配要求显式单写者；不是分布式CAS。
- 云端适配由宿主注入已有ImageFileStorage/JsonStatePort和Appwrite客户端。复用原项目与资源目录；JSON使用独立工具资源索引，不能伪装PNG写进图片专用通道。

当前开发Appwrite桶存在users读取权限且fileSecurity=false，不能作为多租户生产隔离已通过的证据。生产私有存储检查应在CLI和直接后端启动入口统一执行；此检查不会自动修改共享开发桶ACL。
