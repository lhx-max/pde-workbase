# 历史画布承载 profile 存档

以下为独立生图后端迁移前的原文，不作为当前独立部署或资源归属合同。当前入口为 README.md 与 docs/APP_CONTRACT.md。

> 0.8.0 MVP当前合同补充：[MVP_API.md](MVP_API.md)。增加crop/adjust/transform工具、image.edit.save/read与JSON产物读通道。独立完整editor仍按单独适配交付，未改变MA/Provider/staging验收边界。

> 2026-10-22 最新合同增补：本地0.7.0。图片卡片工具为当前方向；下文独立详情模式是历史规划，已暂停。新增产物存储合同见 [ARTIFACT_STORAGE.md](ARTIFACT_STORAGE.md)，逐用户模型授权与生产验收边界见 [APP_AUDIT.md](APP_AUDIT.md)。工具产物持久化已真实云端验证，SVG和重排多图已接到公共动作与画布回填；外部服务仍需独立配置，手动样机编辑的原组件纳入本轮。

> 2026-10-22 图片工具增补：`image.tool` 沿用本合同的版本/幂等/当前用户授权/任务/云端交付，只读取当前节点实际资源并创建新结果。输入schema按工具区分；不修改原图与生图草稿配置。业务存储沿用自己的Appwrite；迁移状态和服务配置边界见 [BACKEND_TOOLS.md](BACKEND_TOOLS.md)。本轮不再实施独立详情模式。

> 2026-10-22 当前变更：不再实施独立详情模式，转为卡片工具。前端工具及当前交付边界见 [FRONTEND_TOOLS.md](FRONTEND_TOOLS.md)；下文详情模式规划保留为历史，不作为本轮待办。

# 图片 App 接手合同：画布内部接入

状态：画布侧组件和两模型生成能力；详情模式、图片 App 领域数据库由后续开发者实现。生图授权与服务合同见 GENERATION.md。

## 本阶段

- App ID：`image`；原生卡 kind：`image`；卡片在画布 `workbenchImages` 中，不能使用 `node.create` 建图片。
- 本包 `/server` 提供 packId/cards/editorApp 元数据，画布挂载后能力清单可发现。业务 App 目录登记与卡包登记是两件事，当前不伪造可调用后端。
- 显示及现有操作继续由画布原生实现。创建用 `image.attach`，后续选择/替换/变换沿用现有动作及版本/回执合同。
- 不迁移图片字节、不建图片 App 数据库、不实现详情模式或 MA 接入。

## 内嵌组件合同

通过 `/react` 安装 `ImageCanvasCard` 和 `ImageModeEntry`，React 18 由宿主提供。组件不导入画布私有代码，不调用画布内部接口。画布按 props 提供 preview/pending/tools 插槽、按钮 chrome、打开回调和错误处理；文件地址与原有编辑工具继续由画布适配器提供。这个阶段只抽出展示框和入口组件，既有裁剪/调色等工具尚未整体迁入图片仓库。完整画布实际挂载这些组件，而不是打开独立测试页作为接入完成。

## 进入图片模式

画布保存当前状态，再调用 `POST /api/apps/canvas/instances/:canvasId/open-editor`，body 为 `{nodeId}`。服务端按当前用户权限查找已注册 `image` App 和已有图片，返回只读打开描述：

```ts
interface CanvasImageEditorTarget {
  appId: 'image'; kind: 'image';
  canvasInstanceId: string; nodeId: string;
  endpoint: string; filePath: string; revision: number; name: string;
  naturalWidth?: number; naturalHeight?: number;
}
```

宿主配置 `CanvasUiHost.openImageApp(target): Promise<void>`，负责进入图片开发者提供的模式。该调用不创建新图片、不写存储，不推导或编造 image App 业务实例 ID。`revision` 是画布观测版本，不是将来图片 App 的内容版本。文件路径只在对应画布内有效，不是全局资产 ID 或授权凭据。

未接宿主回调：提示“图片模式尚未接入”。App 未注册：404 `APP_NOT_INSTALLED`。图片不存在：404；无权访问画布/App：403；图片尚未完成：409 `IMAGE_NOT_READY`。打开失败保留现有图片及现有画布操作，切换到其他画布后不执行旧打开请求。

## 下一位开发者负责

1. 在本仓实现独立 Appwrite 后端与详情模式，明确业务资产、原件/结果/缩略图和版本归属。先决定资源与身份映射，再迁移或复制字节。
2. 后端可用后，通过现有 `/api/apps/register` 登记 `appId=image`、真实协议 endpoint 与实际 manifest；不能把空服务地址标为已接入。
3. 提供模式组件及宿主适配：实现 `openImageApp`，按画布+node+路径/版本解析到同一源图片。不要把 Provider ID、外部 bizId 与画布 ID 混用。
4. 结果回填沿用画布图片动作并检查观测版本/源路径；图片被修改、删除或任务取消后，旧结果不能覆盖当前图。
5. 资源读写、复制和异步任务的业务协议在实现前填写本合同；不为此改外部 MA 宿主。

正式 Provider/远端 MA/staging 未纳入本阶段。卡包可发现、打开事件可交接均不等于图片 App 后端或详情业务已经完成。

## 图片工作区动作（0.3.0）

公开 `/server` 导出 `imageAppManifest`、`ImageConfig`、严格配置校验。画布宿主注入其已有云端 workspace 和媒体执行器，真实挂载 `/api/apps/image`：`image.create/configure/generate/regenerate/status/cancel`。此 host-backed profile 的 instanceId 明确等于 canvasId，input.nodeId 指向图片来源/结果卡。配置和回执与画布共享云文档；不是独立图片领域库或详情模式。Agent 通过图片 App 动作操作内容，画布负责布局和文件挂载。

基础配置：prompt/model/aspect/resolution/count/references；写操作要求 expectedRevision 和 idempotency-key，回执可查询，重复 key 不重复生成。多张是逐张真实任务；没有自动付费重试、模型切换或失败后覆盖原图。模型 done 与画布 delivery committed 分别验证。公开动作和输入 schema 是 `src/app-protocol.ts`，宿主侧完整调用说明为画布仓 `docs/image-cli-contract.zh-CN.md`。
