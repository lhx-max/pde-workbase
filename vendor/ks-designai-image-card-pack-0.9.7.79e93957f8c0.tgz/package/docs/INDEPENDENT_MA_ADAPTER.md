# 独立生图 App 的 MA 适配层

状态：2026-10-23。本文档描述本仓自己的 MA 包装组件与注册清单工厂的合同。包内实现、类型检查与 SSR 契约测试已通过；正式 MA 挂载、宿主凭据注入、注册与 Agent 调用属于宿主侧验收，本仓不宣称已接通。

## 组件：`createIndependentImageMaApp(options)`（`/react` 导出）

- `options.requestForContext(frozenContext)`：**必需**的部署注入认证请求工厂，对每个冻结上下文返回一个 Image 请求函数。该函数由宿主绑定已验证的请求级凭据与 origin；本组件绝不从 `context.actor` 推断身份、不读取宿主私有 `maAuthenticatedFetch`、不使用环境凭据存储，也绝不回退到通用 `fileClient`/`providerClient`。
- `options.onReferenceForContext(frozenContext)`：可选的应用自有「放入画布」投递钩子。缺省时引用控件不渲染，不伪造投递能力；回调失败以固定中文错误兜底，原始异常不外泄。
- 返回的组件结构与发布的 `PluginComponentProps`（`context?/fileClient?/providerClient?/conversation?`）兼容，仅消费 `context`。

## 挂载行为

- 校验完整发布上下文（applicationId/version/instance、providerInstance、biz、session、actor.user/tenant 均为有界字符串）后深度冻结；身份元组包含 `applicationVersion`。
- 相同身份重渲染复用同一 transport；身份变化按 key 重挂载，旧实例的迟到异步结果无法落地。
- 挂载仅经注入请求 `GET /open-platform/v1/instances/{providerInstanceId}` 读取原始 Provider 快照，校验 `protocolVersion`/`providerInstanceId`/`revision` 与 `content.workspace.id`/`revision`（二者必须一致且为正整数），随后以 `createIndependentImageHttpTransport({request})` 渲染既有 `IndependentImageWorkspace`。**挂载不创建工作区**。
- 注入通道的所有同步异常、拒绝或畸形响应统一折叠为固定中文错误（`图片请求失败`/`生图资源投递失败`）；凭据、URL 与宿主内部细节不进入 UI。写路径沿用既有 transport：显式幂等键 + 精确 expectedRevision，不重试。
- 未配置或上下文无效时渲染固定中文 `role="alert"`。

## 清单：`getIndependentImageKitManifest({providerBaseUrl})`（`/app-backend` 导出，React-free）

- 产出结构化 `ApplicationManifestV1`：`schemaVersion:1`、`slug:'designai-image'`、`version` 取自 `independentImageManifest.version`、`instanceMode:'single'`、`protocolVersion:'1.0'`、`frontend.moduleId='@ks-designai/image-card-pack/react'`、`exportName='IndependentImageMaApp'`。
- `providerBaseUrl` 必须是显式 HTTPS，或精确回环（`127.0.0.1`/`localhost`/`[::1]`）HTTP；拒绝空白/反斜杠/控制字符、userinfo、query、fragment 与路径。
- `actions` 共 11 个：现有 9 个写动作映射为 `effect:'write'` + `requiredPermissions:['image.write']`，外加 `image.read`/`image.status`（`effect:'read'`、空对象 schema、`['image.read']`）。`permissions` 显式为 `['image.read','image.write']`；声明权限不等于 MA 侧自动授权。
- **注册方式**：宿主须把 `createIndependentImageMaApp` 生成的已配置组件以 `IndependentImageMaApp` 名注册；`/react` 中同名裸导出在未配置时明确渲染不可用，禁止把工厂本身当组件调用。

## 仍需外部宿主提供

1. 部署注入的 `requestForContext`（绑定可信请求级凭据与 origin）；
2. 以 `IndependentImageMaApp` 为名注册已配置组件的静态 registry 条目与 `providerBaseUrl`；
3. `image.create` 绑定建立后的实例供给（挂载只做已绑定的只读解析）；
4. 真实浏览器挂载、写动作、身份切换与 Agent 调用的宿主侧验收。
