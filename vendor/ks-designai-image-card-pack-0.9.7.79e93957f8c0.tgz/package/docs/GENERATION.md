# 图片生成能力服务

0.2.0 内置 `designai-gpt-image-2`（GPT-Image-2）和 `designai-gemini-image`（Gemini-3.1-Flash-Image）。支持文生图、最多16张 PNG/JPEG/WebP 参考图、五种比例及2K/4K。每次只执行选定模型，不自动切换或重发付费请求。

## 分工与入口

- `/react` 提供内嵌组件；`/server` 提供无 React 的登记元数据。
- `/generation` 提供 `createImageGenerator({credentialProvider,fetcher?})`，输入 request、参考图字节和 AbortSignal，返回真实 `{path,content,mime}`。
- `/service` 提供 `createImageService({authorize,fetcher?})`。宿主验证请求并返回当前请求绑定的 CredentialProvider；服务拒绝浏览器 Origin 请求。
- HTTP适配为 `GET /models`、`GET /config`、`POST /generate`。生成请求包含 taskId/projectId/request/inputs，参考图为 `{path,mime,contentBase64}`；返回 `{path,mime,contentBase64,progress}`。
- 画布负责202任务、等待/取消、Appwrite图片桶与文件索引、卡片状态和任务摘要持久化。组件不直连数据库，不另建图片 App 业务数据库。

生成服务间请求可能持续约11分钟，代理必须配置适当超时，不能自动重试 `/generate`。本服务不提供分布式任务调度/租约；宿主须处理重启与并发执行归属，不能通过重复付费生成补偿。

## 授权

目标为 `codeflicker.corp.kuaishou.com`，使用该目标域的官方当前用户 SSO 凭据，以 `X-KsSSO-Session-Token` 调用。MA 身份、Appwrite 会话与生图目标域授权不是同一种凭据。云端宿主验证 actor、资源权限和用户委托后注入本次调用的 credentialProvider；本服务不自创 MA 项目/组织/用户体系。

显式开发命令：

```sh
designai-image-service --local-user-sso --kcli /absolute/path/to/kcli \
  --token-file /absolute/private/adapter-token --port 17465
```

单用户模式只监听loopback，以服务token保护入口，通过已安装官方 KCLI TokenProvider 获取当前账号目标域凭据。上游凭据不保存到任务、日志或浏览器。生产/request身份模式拒绝启动此runner；正式环境应由宿主集成 `/service` 并注入逐请求授权。当前账号成功不代表 staging 首次授权或多用户隔离已验收。

## 其他边界

通用生图与信息图 Skill 是两个创作工作流，不是两个底层模型。本阶段接通 GPT-Image-2/Gemini 执行；信息图资料整理/风格推荐工作流尚未内置。本机依赖缺少 Sunburst/Flare 脚本，没有宣称这两个型号可用。详情模式仍由另一位开发者实现。

协议参考：本机 `designai-generate-image` 脚本及 DA `apps/daemon/src/media/kuaishou.ts`（参考提交133ee7ead5da741a954331fdf3664eaa32b83b54）。无运行期 checkout 导入或源文件软链。


## 0.2.1：恢复旧 DA 设备授权链路

`/authorization` 导出 `KuaishouDeviceAuth`，从旧 DA `apps/daemon/src/media/kuaishou-device-auth.ts` 适配（Apache-2.0，来源仓 `design/design-ai-client`，文件来源提交 `445a86306da1eb025f125cb034e0e356602b551b`；独立实现不在运行时引用旧仓）。协议保持官方设备绑定 → 身份域 whoami → 生图目标域换票 → username/issuer/audience/有效期校验，每次生成重新校验。仅设备授权持久化到显式私有数据根；OBO 不进入任务、画布或日志。`disconnect` 只删除本服务记录，不宣称撤销平台授权。

本地单用户启动（两个模式互斥，不回退 KCLI）：

```sh
designai-image-service --local-device-sso --device-user <本人SSO用户名> --auth-data-dir /absolute/private-runtime --token-file /absolute/private-adapter-token --port 17465
designai-image-auth start --token-file /absolute/private-adapter-token
# 在浏览器打开返回的官方 authorizationUrl，使用相同 SSO 账号授权
designai-image-auth check --token-file /absolute/private-adapter-token
designai-image-auth status --token-file /absolute/private-adapter-token
```

授权控制口 `/authorization/status|start|check|disconnect` 与生成服务使用同一服务 Bearer 校验，拒绝带 Origin 的浏览器直连。status 是 GET，其余 POST；用户名由本地进程参数固定，HTTP 客户端不能指定用户。未就绪时生成明确失败，不调用模型、不产生重试消耗。设备凭据48小时有效，过期重新 start/check；服务重启可继续使用仍有效授权。

这还不是 MA 多用户认证：正式部署由宿主验证请求用户，再注入该用户的 `domain => deviceAuth.credentialWhenReady(verifiedUsername, domain)`，禁止使用本地 `--device-user` 作为正式可信身份。CLI 两种本地模式均拒绝 production/request 身份模式。额度和扣费对象仍以平台用量回执验收，本包不编造消耗数字。

## 统一验收补充（2026-10-21）

App 配置 prompt 最多 7500 字符；服务执行器的 32000 字符上限是上游协议保护，不代表 App 配置上限变化。图片输出同时检查 MIME 和 PNG/JPEG/WebP 文件头；这用于拒绝明显错误内容，不替代完整图片解码。`/config` 在返回 configured:true 前要求当前请求的凭据提供器可用，实际令牌是否被上游接受仍由真实请求验证。MA 身份、实例范围及动作写权限由宿主执行；没有该能力的宿主不能直接用于共享部署。

统一交付合同：公司画布仓 `docs/four-app-delivery-contract.zh-CN.md`；本仓不得依赖该 checkout 的运行资源。
