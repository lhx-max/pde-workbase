> 0.8.0 MVP增补：[MVP_API.md](MVP_API.md) 记录本轮已补的CPU工具、样机工程与JSON存储接线；下述审计保留其原基线与历史缺口，不代表这些缺口至今未补。正式租户/模型授权与staging边界仍有效。

> 2026-10-22 合并main后的重新核验：以 [联调前后端与存储核验](PREINTEGRATION_STORAGE_AUDIT.md) 为当前真源。8项工具结果真实云持久化通过，但样机工程、宿主JSON产物接线、editor存储统一和生产隔离仍有缺口。下文为历史审计。

> 2026-10-22 工具接线增补（0.7.0）：原版完整工具条、打光/多角度/扩图/涂抹消除/快速定位/重排面板已接入；SVG和重排多产物已通过真实Appwrite与HTTP全链路保存、挂载、重启读回。原手动样机编辑器已迁入图片包，外部曲面识别等仍是显式能力端口。以下0.6.x审计为背景，其“多产物未接线”状态已被本增补取代；生产隔离和MA/staging限制仍有效。最终证据见画布仓docs/verification/image-ui-completion-20261022/。

# 图片 App 审计与交付边界 · 2026-10-22

结论：这是已嵌入画布的有界图片 App，还不是已完成生产验收的完整图片平台。当前本地包0.7.0；未发布npm、未推送Git。本轮暂停独立详情模式，沿用自己的Appwrite，迁移原工具组件与处理逻辑。

| 方面 | 当前结论 |
| --- | --- |
| 注册与组件 | 独立仓和npm包；appId=image、kind=image。宿主注入媒体执行器后登记，instanceId等于canvasId；不新建用户/组织系统。 |
| 后端边界 | 模型、工具、鉴权端口在Node服务端；浏览器不持上游密钥。宿主保存画布布局和资源引用，图片包维护工具语义。安装包不会自动部署服务。 |
| 租户/鉴权 | 宿主MA身份回查，租户/业务/实例范围和动作写权限；伪造浏览器身份不被信任。测试覆盖越权、只读、外部项目/节点/任务；真实MA/staging身份未验收。 |
| 模型身份/消耗 | 新增/request-bound-media，可信currentActor、authorize、credentials三个端口，调用前捕获用户，逐用户取授权。并发用户、缺失身份、拒绝写和无凭据均通过fixture测试。静态HTTP Bearer只做服务认证；生产MA启动禁止将其冒充逐用户模型授权。真实授权broker和用量对账未接入。 |
| 存储 | 图片字节和大型编辑状态JSON存Storage；manifest/job存云端journal，画布存布局/引用。无base64图塞进画布业务记录。PNG/SVG/JSON/蒙版等六产物经过真实Appwrite保存、全新投影读回、幂等重放0新增写入。 |
| 隔离阻塞 | 开发桶canvas_assets_v2仍fileSecurity=false、含read(users)；permissions=[]的文件不能抵消桶级读取。不能用于证明生产多租户私有隔离。生产启动统一校验桶/集合策略，不合格阻断业务IO；未修改共享开发桶ACL。 |
| 工具完成度 | 原版裁剪、调色、旋转/翻转及图层顺序前端已迁移；打光、多角度、定位修改、扩图等单图服务适配；VTracer实际CPU矢量化可产SVG。完整原工具面板、多产物画布交付尚未全部挂载。 |
| 外部能力 | GPU/分层/OCR/样机曲面等需要正式Provider及协议验收；未配置明确不可用，不以fixture冒充真实模型。 |

## 部署接线

/request-bound-media导出createRequestBoundImageMediaAdapter。currentActor必须来自服务端验证过的身份上下文；authorize验证当前project及写动作；credentials只返回该用户的CredentialProvider，不接受浏览器自报身份或固定个人凭据。异步恢复任务必须重新建立可信身份/授权上下文；没有上下文应失败，不借用其他用户。

/artifact-contract是无React/Node的DTO与校验；/artifact-store注入journal/files/authorize。namespace与projectId必须由宿主从验证后的业务/实例映射得到。当前journal要求显式单写者，不支持多副本并发写。失败/取消保留原图和已跟踪产物，不自动重启付费任务。

## 独立验收证据

画布仓docs/verification/image-tool-persistence-20261022/README.md为主代理复验结论；executor报告是执行记录，不代表最终验收。当前图像包94个测试通过，画布本批安全/存储/隔离40个测试通过。模型多用户测试是fixture，云端六产物是实际Appwrite；均不等同正式MA调用、真实GPU或staging全流程。
