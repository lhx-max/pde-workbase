# 图片卡片前端工具迁入 · 2026-10-22

本轮改为卡片工具，不继续独立详情模式。裁剪比例、归一化坐标及拖动算法来自 MarioDesign-FT/design-canvas 提交 996622df61943932a0f1e8adfee26c7bf5c53e3a 的 excalidraw/src/main.jsx；17项调色参数和像素处理来自 imageAdjustments.js，Apache-2.0，保留来源声明。未复制完整 Excalidraw 编辑器、宿主桥、凭据、用户数据或后端。

`/react` 导出 ImageCropTool、ImageAdjustTool、ImageTransformTool。宿主提供授权原图 src、name、busy、onCancel、onCommit(File,{width,height})。onCommit 必须等待云端保存完成；false 或抛异常保留编辑供重试。预览最长边1200，保存处理原始尺寸；不将预览当产物。Web Worker执行调色及编码；取消/卸载终止处理。返回PNG以保留Alpha。旋转/翻转为浏览器适配新增，不冒充来自对方的独立模块。

支持自由、原始比例和9种固定比例，像素宽高、八向拖动、移动、键盘边框微调、重置；调色沿用对方光线/颜色/细节/效果17项。按用户最新要求撤回自建弹窗。直接迁入原CanvasPanel、ImageRatioList、CropSizeInput、adjustmentIcon及原styles.css/selectionActionToolbar.css，Shadow DOM隔离样式，仅将html/:root选择器适配为:host。裁剪框沿用createCropOverlayElements的遮罩/边框/三分线参数，在原画布图片上交互；宿主提供图片DOM坐标，替换Excalidraw专用定位。原调色面板无底部完成按钮，关闭时保存当前调整，失败保留。LayerOrderPanel原菜单结构接宿主层级回调。原标注、对话、下载和资源保存仍由宿主提供。AI快速标记及其他后端工具不在本轮。

要求现代浏览器支持 Worker、createImageBitmap、OffscreenCanvas；缺失明确报错，无后端降级。图像上限3200万像素。层级属于宿主节点操作，不直接移植Excalidraw元素层级。

## 0.7.0 原版工具条与面板

/react的ImageCardTools组合原SelectionActionToolbar、RelightPanel/Scene/ColorPopover、MultiAnglePanel/OrbitPreview、扩图自由画布/比例、消除涂抹、定位评论、重排资源位等组件。原CSS在Shadow DOM隔离，宿主仅注入资源/尺寸/执行/上传和原生画布动作，不复制到画布仓。快速定位修改与画布标注独立；前端绝不直连模型平台。

原样机MockupEditor及透视映射、曲面几何、材质、遮罩、撤销/重做与原尺寸渲染模块一并迁入，公开OriginalMockupEditor。手动平面贴图与PNG/JPEG渲染不依赖外部识别服务；云端结果由onRender交给宿主创建派生图片。onDetect/onFuse/onSaveEditState是明确可注入端口，未配置不可假成功。未接编辑态保存时，只能说保存了栅格结果，不能宣称可恢复的图层工程已存储；不使用localStorage作权威草稿。

控件只向image.tool提交公开参数：point:{x,y}/instruction，mask项目路径，targetCanvas/sourcePlacement，资源位别名或尺寸数组。服务URL、蒙版预览URL、内部ratio/scale状态不进入任务参数。关闭或卸载后不继续提交异步上传结果；网络不确定时重试复用操作键。


## 图片工具栏自定义（2026-10-22）

原版 ToolbarOrderPreview / CanvasModal / SelectionActionToolbar 的图片模式与 CSS 继续复用，适配 React 18 类型、宿主 target 和 ShadowRoot 焦点/事件边界。原版调整/层级图标恢复，旋转、画布标注、对话、曲面端口使用各自明确图标；AI 点选修改与画布标注保持独立。

默认固定九个工具：快速标记修改、拆分图层、无损放大、矢量化、样机、多角度、打光、智能重排、AI 扩图。更多菜单始终可用，容纳未固定/窄屏溢出工具、保存到资产及自定义入口；下载保留独立按钮。自定义支持拖动（含边缘滚动/取消）、键盘左右/Home/End排序、固定/取消固定、名称显示、恢复默认、取消/保存、焦点约束和存储失败提示。允许用户自己固定超过九项，窄屏自动移至更多。

名称提示有独立 ShadowRoot 内 renderer，支持鼠标悬停和键盘聚焦；不是仅写 data-mario-tooltip。偏好存浏览器键 @ks-designai/image-toolbar.v1，只保存工具顺序和名称显示，不含业务数据、图片、用户授权或凭据；不是跨设备云同步设置。损坏/禁用存储时不影响图片业务，保存失败显示明确提示。源 UI 历史 localStorage key 不复用，默认不会带入对方仓库的十四项固定配置。

### 工具栏跟随画布缩放

2026-10-22：复用现有 CanvasPanel 与原版锚点算法；按目标图片 DOM 的屏幕宽度/布局宽度计算宿主缩放，同步投影整条工具栏。间距由为原版旋转手柄预留的36px改为8个画布单位；按投影后尺寸进行边界避让和窄屏溢出。自定义设置弹窗继续使用原版组件/CSS。


### 画布边缘跟随（2026-10-22，后续用户修正）

工具栏须和图片一起移出视口，取代此前限制在屏幕内/避让宿主控件的策略。图片 App 接收可选 getToolbarViewport 回调，仅获得宿主画布屏幕矩形；工具栏保持图片上方8个画布单位的固定锚点，不横向钳位、不翻到图片下方、不单独拖动。阴影门户按宿主画布矩形裁切，图片完全离屏时隐藏，拖回恢复。菜单和自定义功能继续复用原组件。
