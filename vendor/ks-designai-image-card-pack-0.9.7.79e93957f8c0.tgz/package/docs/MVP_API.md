# 图片 App MVP CLI/API · 0.8.0 · 2026-10-22

本轮从 main 9e83f95 开始，在 feat/image-mvp-api-20261022 实现；未部署staging、未发布npm。旧动作继续兼容，新动作通过同一 canvas-cli / App API 调用，不新增一套Agent执行器。

## 范围与复测

- 原 image.create/configure/generate/regenerate/status/cancel 和 image.tool 保留。创建、配置、重放的旧CLI已在真实云端重新执行；生成/取消/越权与重试走HTTP fixture回归，不额外付费。
- 原8项工具加3项无模型工具，共11项走真实HTTP执行→任务→Appwrite文件→画布回填→新缓存恢复；模型响应为fixture，CPU矢量化/裁剪/调色/翻转为实际执行。
- 9个公开动作、15个工具声明；外部服务未配置时仍明确不可用。登记/schema/安装不等于服务可执行。

## 新增无模型工具

仍用 image.tool，input只带 nodeId、kind、params；源文件由服务端从当前节点解析。原图保留，新结果单独交付。

| kind | params | 约束 |
| --- | --- | --- |
| crop | `{x,y,width,height}` | 原图像素坐标，正整数尺寸，完整位于原图内 |
| adjust | `{exposure:30,contrast:10,...}` | 复用界面17项调整算法及确定性颗粒；原有取值范围；MVP最多800万像素 |
| transform | `{rotation:90,flipX:true,flipY:false}` | rotation为0/90/180/270，翻转是布尔值；先沿原图坐标翻转再顺时针旋转 |

支持PNG/JPEG/WebP栅格源。以上工具不获取模型凭据，不调用模型，不产生模型费用。未知字段、无效尺寸、越界/本机/其他项目路径拒绝。

```sh
canvas-cli request GET /api/apps/image
canvas-cli request GET /api/apps/image/instances/CANVAS_ID/tools
canvas-cli apps state image --instance CANVAS_ID
# crop.json: {"nodeId":"IMAGE_ID","kind":"crop","params":{"x":0,"y":0,"width":512,"height":512}}
canvas-cli apps call image image.tool --instance CANVAS_ID --body-file crop.json --expected-revision REV --idempotency-key crop-001
canvas-cli apps receipt image --instance CANVAS_ID --id crop-001
```

## 样机工程保存与恢复

- image.edit.read：只读，input `{nodeId}`，返回 result `{nodeId,revision,sourcePath,editRevision,document}`；尚无工程时document=null。**使用服务端返回的sourcePath，不使用原上传别名。**
- image.edit.save：写，input `{nodeId,document,expectedEditRevision}`，必须expectedRevision与稳定幂等键。expectedEditRevision取自上次工程读/写回执，不能用新画布revision替代；工程并发修改明确409，禁止旧草稿悄悄覆盖。document严格按manifest中的schema：`{version:2,basePath,layers,surface}`。
- 工程保存的是项目资源路径、图层、四角坐标、材质、混合、不透明度、光影、褶皱、遮罩以及平面网格，最多8贴图层、128KiB工程。拒绝临时URL、二进制和凭据；dense-b曲面仍等待其Provider/资源合同。
- 原图被替换时明确409；文件不存在拒绝；不把旧工程套在新图片上。资源逐件校验属于当前项目。
- 大型数据仍作为JSON文件保存到云Storage；画布只持工程路径和来源引用。普通canvas PATCH不能篡改工程索引或回执。
- UI实际传入保存/加载回调，加载全部贴图后才允许编辑与保存；关闭/刷新后能继续编辑；恢复失败不静默初始化空工程。
- 保存回执先保留在同一原子画布更新里；后续保存会先将已完成工程回执写入持久云端归档再移除其画布项，旧幂等键仍可查/重放，避免自动保存耗尽256条生成回执容量。原生图动作的长期回执归档仍独立待办。

```sh
# read.json: {"nodeId":"IMAGE_ID"}
canvas-cli apps call image image.edit.read --instance CANVAS_ID --body-file read.json
# 保存前重新读取工作区revision，save.json的basePath使用read返回的sourcePath
canvas-cli apps call image image.edit.save --instance CANVAS_ID --body-file save.json --expected-revision REV --idempotency-key edit-001
canvas-cli apps receipt image --instance CANVAS_ID --id edit-001
```

image.edit.save/read只负责可编辑工程；手动样机的栅格化仍使用原浏览器渲染器与宿主PNG保存端口，未伪造一个不等价的服务端渲染器。Agent可读取/配置工程，完整无浏览器的样机栅格化、矢量标注编辑命令未纳入本MVP。

## JSON工具产物

宿主现在向媒体服务注入CloudToolArtifactFiles。JSON与PNG/SVG一并保存计划/分件回执，完整保存后才done。读取使用：

`GET /api/apps/image/instances/:canvasId/artifacts?path=<encodeURIComponent(projectRelativePath)>`

返回 `{requestId,data:{document}}`，沿用App entitlement、项目/实例读授权；只读当前项目media-tools命名空间的JSON产物，不接受浏览器自报namespace/身份。没有文件、跨租户、不合格路径明确拒绝。

这补齐存储接缝，不代表分层/OCR、ComfyUI、去背景、自动曲面Provider已接通，也不代表复杂分层编辑UI已开发完成。

## 仍留在后续的事项

- 外部GPU/分层/OCR/曲面/透明PNG/ComfyUI的正式服务配置和真实业务效果。
- editor完整编辑器的宿主协议与存储统一；本MVP保持卡片接入，不替换成另一整套编辑器。
- 真实MA身份、逐用户模型授权/消费、生产私有桶及双用户隔离、正式登记和staging。
- 超大工程、历史版本管理/GC、无浏览器样机渲染、矢量标注编辑API；未提交的普通裁剪/调色滑杆草稿并不因结果API而自动成为云工程。

旧审计见PREINTEGRATION_STORAGE_AUDIT.md；本轮实际证据在docs/verification/mvp-api-20261022。不要用旧“尚未提供CLI”的段落覆盖本合同，也不能用本合同推断线上已经完成部署。
