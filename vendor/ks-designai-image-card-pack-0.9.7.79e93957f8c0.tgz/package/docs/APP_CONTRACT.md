# 生图 App 开发与验收合同

修订：2026-10-23。默认交付为独立生图后端和可注入 transport 的 React surface。实现、协议 fixture、正式 MA 安装、Agent 自主调用与 staging 分别验收；历史画布承载合同完整保存在 [历史合同](LEGACY_CANVAS_APP_CONTRACT.md)，不再决定当前资源归属。

## 范围与交付

仓库 `design/designai-app-image`；业务与资源审批负责人李鹏。生图拥有工作区、原件、结果、配置、任务、编辑工程、持久回执和恢复信息；画布只拥有布局、完整作用域的资源引用、经认证的预览与自身投递回执，不保存第二份生图业务真源。

后端从 `/app-backend`、`designai-image-app-server` 交付；界面从 `/react` 提供 `IndependentImageWorkspace` 和 `createIndependentImageHttpTransport`。`designai-image-app` CLI 调用同一 HTTP 领域服务，不另建业务库。`editor/` 是另行构建的编辑器项目，见 [迁移记录](FULL_CANVAS_MIGRATION.md)，不能自动代替 surface 或共享其云配置。

Node 24、pnpm 10.33.2、TypeScript；React 18.3.1 由消费宿主提供，服务端保持 React-free。日常使用功能分支，main 为共同集成分支；合并、推送、发布、部署按维护者授权执行，不修改外部宿主、SDK、菜单或 Agent 编排。

## 身份、实例与资源

用户、租户、业务空间及应用实例目录归 MA。本 App 通过可信 authority 回查当前 SSO 与实例，检查完整 `teamId/bizId/applicationId/applicationInstanceId/providerInstanceId`；客户端 actor 不构成认证。写入额外需要精确动作授权，默认只读。跨业务、跨实例或撤权后，资源路径、旧回执及预览也必须重新拒绝访问。

Provider 的完整 MA 作用域绑定一个 Image 工作区；providerInstanceId 不等于业务主键。`image.create` 显式创建并持久保存绑定；打开、snapshot、read、status 均不隐式创建。缺绑定返回明确错误，不借用其他实例。

开发资源为 Appwrite `grworkspace/image_app_dev/app_runtime_state` 与独立私有桶 `image_assets_v2`。集合/桶默认授权为空，documentSecurity/fileSecurity 开启。正式环境使用另行批准的独立资源和最小权限运行身份。缺配置、schema、namespace 或权限时启动拒绝，不回退画布桶或本地文件。资源声明、初始化与身份要求见 [部署合同](../deployment/README.zh-CN.md) 和 `deployment/appwrite-schema.json`；谁负责仓库，谁审批其资源。

## 公开 API 与版本合同

精确业务 schema 以 `independentImageManifest` 为准。业务响应为 `{requestId,data}` 或 `{requestId,error}`；Kit Provider 直接信封不能与它混用。

| 能力 | 路径与约束 |
| --- | --- |
| manifest / 能力 | `GET /api/apps/image`；`GET /api/apps/image/capabilities`，静态声明不代表运行时可用 |
| 工作区 | `GET /api/apps/image/workspaces`；`POST /api/apps/image/actions/image.create`，创建要求稳定 idempotency-key |
| 完整状态 | `GET /api/apps/image/instances/:workspaceId/state`，含工作区、资源元数据和任务 |
| 原件/结果 | `GET /api/apps/image/instances/:workspaceId/assets/:assetId`，认证后返回完整原始字节 |
| 上传 | `POST /api/apps/image/instances/:workspaceId/assets`，input 为 path/mime/role/contentBase64，附 expectedRevision 与原幂等键 |
| 写动作 | `POST /api/apps/image/instances/:workspaceId/actions/:actionId`；configure/generate/regenerate/tool/edit.save/cancel/archive 均检查当前权限与版本 |
| 任务 | `GET /api/apps/image/instances/:workspaceId/jobs/:jobId` |
| Kit snapshot | `GET /open-platform/v1/instances/:providerInstanceId`；直接返回 protocolVersion/providerInstanceId/revision/summary/content/availableActions |
| Kit action | `POST /open-platform/v1/instances/:providerInstanceId/actions/:actionId`；严格核对信封、路径/身份及 header/body 原幂等键，返回直接 Provider 结果 |

Provider 支持 9 个业务写动作和 image.read/image.status；读动作 input 为空且不传 expectedRevision。当前 snapshot 仅含 workspace/jobs，完整资源及字节通过独立 HTTP API 读取。MA manifest 转换为公开的 id/effect/inputSchema/requiredPermissions 形状，不直接提交业务 manifest 的 actionId/mode。

一次逻辑写入保留原输入、身份范围、预期版本和幂等键。持久回执在当前授权下重放；过期版本、同键不同输入拒绝。网关不得重新生成键，响应不确定时先查回执或显式按原请求重放，不自动重新派发有成本动作。

## 文件、任务与恢复

原件上限 30,000,000 字节，超限在业务写入前拒绝；Appwrite 固定按十进制 5,000,000 字节分块，原字节 SHA256 读回必须一致，不重新编码或静默切换 profile。base64/JSON 开销计入每层网关限制。

任务先持久接受再执行；结果保存本 App 私有桶，任务完成与画布引用投递分别验收。部分多图成功后保留已付费产物；取消、撤权和迟到结果不得覆盖新状态。编辑工程保存资源路径、结构与版本，不保存临时 blob URL 或凭据；缺资源明确失败。

单写者、单副本、stop-first；正常停机 flush 并释放自己的锁。遗留锁不自动抢占；非终态付费任务恢复不自动重新调用模型。临时目录仅缓存，不是权威存储。

## 模型与前端

业务权限与逐调用者模型授权分别验证。可信服务端 adapter 按已验证 caller 获取当前模型凭据；浏览器、CLI、任务和日志均不获得它们。维护者设备授权仅用于显式本地测试，不是生产 broker。

designai-gpt-image-2 与 designai-gemini-image 的 2K 方图为 2048；高清档 GPT 原生方图 2880×2880、Gemini 方图 4096×4096，不插值伪造统一 4K。CPU 和已配置工具按运行时能力提供；GPU、分层/OCR、自动曲面、透明背景模型及 dense-b 工程未配置或不支持时明确 unavailable/unsupported。

surface 通过部署注入的可信 request/transport 工作，不读取宿主私有认证实现。MA 通用 fileClient 不自动拥有 Image 私有文件；context 有值不代表认证通道存在。挂载只读已有绑定；缺配置显示不可用，切换身份或版本后旧请求不能写入新界面。正式静态登记、可信请求/私有资源桥和 Agent 工具发现各自验收。

## DesignAI 工作流

552 高清、568 重绘/消除及受限 163 扩图通过请求调用者绑定的服务端适配接入 `image.tool`。工作流选择和提交阶段持久化；未知提交与重启不自动重提，结果只入本 App 私有桶。具体映射、原生尺寸/蒙版/落位限制及外部认证缺口见 [DesignAI 工作流合同](DESIGNAI_WORKFLOWS.zh-CN.md)。

## 验收出口

交付固定版本/hash 的 npm 包、服务镜像、外部配置模板、部署/恢复说明、API/CLI/manifest 和可复现证据。包在干净目录安装、类型检查并实际挂载，包含 Worker，不依赖相邻检出或开发软链。

分别验证：私有 ACL/schema；真实云端字节与空缓存重启；完整身份/实例/动作拒绝；版本/幂等/回执；任务成功/失败/取消/部分成功/恢复；编辑工程；各适用工具及两模型；安装包和只读非 root 镜像；实际 CLI/Agent；画布引用/预览；正式 MA；staging。外部 CLI Agent 不代替 MA 自主调用，未提供的认证、目录、模型 broker 或工具桥保留为未通过项。
