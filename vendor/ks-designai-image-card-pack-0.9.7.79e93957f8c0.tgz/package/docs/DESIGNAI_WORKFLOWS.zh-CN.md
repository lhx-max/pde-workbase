# DesignAI 工作流接入合同

版本：Image App 0.9.4。资源归属与审批负责人：李鹏。

## 接口与范围

本 App 通过服务端适配调用 DesignAI 工作流。其内部使用 ComfyUI 不改变应用的接入合同；本 App 使用 `UseDesignAIWorkflow` 提交、`GetDesignAIResourceList` 查询，不直接猜测或访问 ComfyUI `/prompt`。

来源为本仓 `editor/server/design-ai-workflow.mjs`、`design-ai-upload.mjs`、`design-ai-upscale.mjs`、`masked-composite.mjs`、`upscale-validation.mjs` 和 `ai-service.mjs`，对应李鹏分支 `workflow-image-three-tools-20261023`、提交 `74057d932e501e46f676d028a9f84b7c68d5e1bb`。根后端移植为 TypeScript，运行时不导入 editor，不使用其本地素材目录、任务文件或临时登录桥。

| 工具 | 工作流 | 已有接口映射与执行限制 |
| --- | --- | --- |
| 高清放大 | 552 | 2/4 倍；工作流只有图片输入，不传虚构 scale 参数。原生结果必须达到目标尺寸和比例，只允许向下归一，不插值、不串联重提。透明度最终从原图恢复一次。 |
| 局部重绘 | 568 | 图片与修改提示词；蒙版生成低透明度紫色引导，最终仅合成蒙版内 RGB，保留蒙版外 RGBA 与原始 Alpha。不是原生 mask 节点。 |
| 消除 | 568 | 图片与消除提示词；保护蒙版外像素，保留原图 Alpha，使用消除专有背景修复和渐变融合；不将该融合用于重绘。 |
| 扩图 | 163 | 图片和目标宽高；仅开放居中 4:3 profile，不接受自由落位或先缩放原图。保留原图区像素并校验边缘。该限制不构成所有素材视觉质量已通过的承诺。 |

李鹏已有证据中，552 大图 4 倍可能因原生尺寸不足失败；163 自由落位曾出现拼贴/重复山体，585 上游返回 500，568 替代扩图有白边/装饰框。这些路径不作为可用默认项，不因另一个模型可用而自动降级。上游结果仍须做业务素材的视觉验收。

## 身份、路由与持久化

仍使用 `image.tool` 的现有动作、CLI 和完整 MA 资源作用域，不增加浏览器可配置的上游 URL、creator、业务 token 或 Cookie 字段。App 写权限与 DesignAI 的请求调用者授权分别检查；CodeFlicker 模型凭据不能代替上传登录态或工作流 RPC 授权。

通过可信 `designAi(caller)` 为当前已验证调用者解析接口；配置此部署路由后，四项工具的授权或服务失败均明确拒绝，不自动改用 GPT、Gemini 或其他 GPU。CPU 工具与正常两模型生成保持各自授权路径。

新任务接受时在私有状态库冻结工作流及 `planned` 阶段。执行必须按以下顺序通过持久化屏障：

1. 保存 `submitting`，再上传输入、提交唯一一次远端任务。
2. 收到合法任务号后保存 `submitted + resourceId`，再查询或下载。
3. 下载、处理并写入本 App 私有桶，校验归属及来源版本后完成任务。

任务回执只含 provider、workflowId、phase、resourceId；不保存上游 URL、身份凭据、creator 或业务 token。未知提交不自动重试；同幂等键重放只读原回执；重启将非终态任务标记 interrupted 并保留已知任务号。`DesignAiImageTools.execute(..., {remote})` 支持只查询原任务的适配级恢复；本版本不提供自动恢复或新的业务 HTTP 恢复动作。运维恢复必须沿原任务、当前授权及原资源范围实施，禁止把“重新生成”当恢复。

画布继续只保存资源引用、预览与布局。输入、蒙版、结果及任务真源均属于独立 Image 存储；上游 CDN 地址是临时传输位置，不能作为交付资源真源。

## 部署接线

通过 `/app-backend` 或 `/backend` 导出 `createDesignAiImageTools`、`createDesignAiUploader`、`createDesignAiDownloader`、`createDesignAiTestHttpRpc` 和对应类型。

运行时新增可选 `IMAGE_DESIGN_AI_ADAPTER=/absolute/installed/image-design-ai.js`。模块必须导出：

```ts
export const environment = 'production'; // 显式本地测试使用 'test'
export async function designAi(caller) {
  // 部署方实现的可信认证桥，按 caller 的完整已验证作用域授权。
  const grant = await resolveDesignAiAuthorization(caller);
  return createDesignAiImageTools({
    creator: grant.creator,
    bizToken: grant.bizToken,
    uploadImage: createDesignAiUploader({authenticatedFetch: grant.authenticatedFetch}),
    rpc: grant.rpc,
    downloadImage: createDesignAiDownloader(),
  });
}
```

示例中的认证桥由部署方提供，不是本仓已有服务。`NODE_ENV=production` 拒绝 `environment='test'`；测试 HTTP transport 必须显式 `testMode:true`，生产 RPC 由可信桥注入。无全局 Cookie、示例 token 或其他同事凭据默认值。上传/下载只允许公司 CDN HTTPS 地址，禁止重定向与任意文件/内网 URL，并受字节、像素和超时限制。

`IMAGE_MODELS` 控制原有两模型；DesignAI 独立配置，可在显式关闭两模型的本地测试中使用。capabilities 返回当前调用者的四项服务状态及扩图/高清限制；静态 manifest 不构成可用性证明。

## 验收口径

本轮按维护者确认完成本地验收。接口协议使用可控 transport；像素处理使用真实 PNG，持久化测试分别注明协议 fixture 或真实私有 Appwrite。验收包含提交次数、回执落盘顺序、读回、鉴权撤销、超时/取消、未知提交、重启不重提、制品安装和现有两模型回归。

尚无可复用的 DesignAI 上传认证桥及正式 MA 运行身份。真实工作流调用、素材视觉效果与正式 MA/staging 验收不得据此记为通过。
