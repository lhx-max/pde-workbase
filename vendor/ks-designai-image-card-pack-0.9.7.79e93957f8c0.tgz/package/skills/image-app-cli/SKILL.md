---
name: image-app-cli
description: Discover and operate an authorized independent Image App workspace through the installed designai-image-app HTTP CLI.
---

Use for reading or editing an explicitly selected Image workspace, importing
resources, running supported image tools, or observing generation jobs. Requires
Node 24, the installed CLI, a reachable IMAGE_APP_URL and trusted request-bound
authorization. Missing configuration or permission means unavailable.

1. Run `designai-image-app --version`, `--help`, then `manifest` to discover the
   actual independent profile and action schema. Installation does not grant
   access or register a tool in an Agent runtime.
2. Read `state --instance WORKSPACE_ID`. Use the returned Image workspace ID,
   owned asset IDs/paths and current revision. A Canvas ID or MA instance ID is
   not an interchangeable business workspace ID.
3. Create a JSON body file using the live input schema. Send writes with
   `request POST API_PATH --body-file FILE --expected-revision N
   --idempotency-key KEY`. Workspace creation does not require a baseline.
   Upload/operation/execute actions all retain their own exact input.
4. A 202 response identifies a durable job; it does not mean generation or
   Canvas delivery succeeded. Observe the returned job ID and read canonical
   assets before reporting completion. Never change model or automatically
   retry uncertain paid work. Reuse the original logical key and request.
5. Read state again and download actual output with `asset --instance ID
   --asset ASSET_ID --output-file ABSOLUTE_NEW_PATH`. Check bytes and hash.
   Errors have nonzero exit status; model text alone is not execution proof.

Credentials come from the execution environment, never prompts, URLs, business
JSON or stdout. Use the MA delegation channel or the explicitly configured
service identity, never self-declared actor fields. Do not read another App's
bucket or substitute Canvas state for Image-owned configuration/jobs/assets.
Canvas placement/delivery is a separate authorized integration step.
