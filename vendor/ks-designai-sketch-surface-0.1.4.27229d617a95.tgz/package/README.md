# Sketch Surface

Install `@ks-designai/sketch-surface@0.1.2` from `https://npm.corp.kuaishou.com/`.
Use one React/ReactDOM 18.3.1 renderer and Excalidraw 0.18.x. Import
`@ks-designai/sketch-surface/styles.css`, then mount `SketchEditorPane` with
an authenticated `SketchDocumentApi`, real sketch metadata and a leave guard.
Scene writes require the exact server content hash/base content; keep dirty drafts on failure.

The `/da` export supplies `SketchEditorApp`, `providerSketchApi`,
`createAuthenticatedSketchProvider` and `createSketchManifest(providerBaseUrl)`.
The host supplies its verified context and authenticated ProviderClient. Tokens
must be injected by the host; actor fields do not authenticate anyone. Never
embed service/Appwrite secrets in the browser. Same Provider ID maps to the
same sketch across UI and Agent. Await registerBeforeLeave before unmounting.

Mutating calls through `providerSketchApi` track one identity-scoped pending
record. If a write outcome is uncertain — network drop, abort after dispatch,
5xx, or an invalid/mismatched success envelope — the call rejects with a typed
`SketchProviderError` whose `code` is `SKETCH_OPERATION_UNCERTAIN` and
`uncertain` is `true`. It carries `requestId`, `idempotencyKey`, `actionId` and
context identifiers only; never headers, credentials or the submitted input.
While a record is pending, further mutations fail locally before any network
call and the same request id is never rotated. Resolve it through
`api.recovery` (also attached to the error as `error.recovery`):

- `pendingRecovery()` — read-only snapshot of the interrupted operation.
- `retryUncertain()` — replays the exact frozen key, body and revision. The
  server's same-key dedupe returns the original outcome instead of applying
  the mutation twice. Auth headers are recomputed live on every attempt.
- `reconcileUncertain({providerRevision})` — clear after the caller confirmed
  the outcome, for example by reading current server state.
- `discardUncertain()` — clear after the caller verified the operation did not
  commit or chooses to abandon it.

A successful read or a revision change never clears the record implicitly; a
validated 400/403/404/409 envelope is a definite error and needs no recovery.
`action()` also accepts an optional fifth argument `{requestId, idempotencyKey,
signal}` — ids must be 1–128 printable ASCII; an `AbortSignal` already aborted
before dispatch is a definite failure, after dispatch it is uncertain. Pending
state lives only in memory per `providerSketchApi(context)` instance; nothing
is written to browser storage.

Scoped browser recovery is a cache of unsaved drafts, with explicit restore,
export and discard. The authority remains the sketch App's Appwrite storage.
The package contains JS, types, CSS Modules and fonts, with no sibling checkout
or backend dependency. Installation does not register an App in MA or deploy a service.
See the repository docs for deployment, permissions and real acceptance evidence.
