# 图片 App · DesignAI Image

独立维护的图片 App：以 npm 组件嵌入画布，通过统一 App API 和 canvas-cli 提供生图、图片工具与样机工程读写。组件不复制到宿主源码，不依赖相邻 checkout 或软链。

## 当前版本与进度（2026-10-22）

| 项目 | 当前状态 |
| --- | --- |
| npm 包 | `@ks-designai/image-card-pack@0.8.0`，已构建、打包并安装到本地画布验证；**0.8.0 尚未发布公司 npm** |
| 共同集成分支 | `main`；本轮功能分支 `feat/image-mvp-api-20261022` |
| 公司 Git | `git@git.corp.kuaishou.com:design/designai-app-image.git` |
| App / 原生卡 kind | `image` / `image`；工作区 profile 的 instanceId 等于 canvasId，nodeId 定位卡片 |
| 运行环境 | Node 24、pnpm 10.33.2、TypeScript；卡片使用宿主提供的 React 18 |
| registry | `https://npm.corp.kuaishou.com/` |
| 许可证 | Apache-2.0；保留原组件来源和适配记录 |
| 线上状态 | 未部署 staging；未完成正式 MA 登记、真实用户鉴权与消费验收 |

卡片工具是当前交付入口，**不继续开发独立详情模式**。李鹏迁入的完整编辑器保留在 `editor/`，是独立构建和验收的另一交付物；同仓不代表两种前端、身份和存储已自动统一。

## 已接通的 MVP

- 原有创建、配置、生成、重新生成、状态查询、取消和工具动作继续兼容。
- 提示词、模型、比例、分辨率、张数、参考图可通过 API/CLI 配置；修改配置不会自动调用模型。
- 无模型 CPU 工具：像素裁剪、17 项图片调整、90 度倍数旋转及水平/垂直翻转；保留原图，新结果独立回填。
- 样机工程云端保存/读取：保存资源路径、贴图层、坐标、材质、混合、不透明度、光影、褶皱、遮罩和平面网格；界面恢复全部资源后才允许编辑，刷新后可继续编辑。
- PNG/SVG 和结构化 JSON 工具产物经宿主云端存储；JSON 有受授权保护的读取接口。
- 写动作的全局版本、工程独立版本、稳定幂等键、持久化工程回执及重启恢复。

共 **9 个公开动作、15 个工具声明**。声明数量不等于服务可执行数量：GPU、分层/OCR、去背景、曲面和 ComfyUI 等依赖未配置时明确不可用，不模拟成功。

完整参数、限制、命令及剩余项以 [MVP API 合同](docs/MVP_API.md) 为准；历史材料与该文档冲突时，以当前合同和实际 manifest 为准。

## 架构与职责

```text
MA / DA 宿主（正式接入待验收）
  └─ 完整画布组件
       └─ 安装本包 /react，内嵌图片卡片及工具面板

Agent → canvas-cli → 宿主图片 App API → 图片执行适配器
                         ├─ 本包 CPU 工具 / 生图 / 已配置的外部 Provider
                         └─ 宿主云存储、权限、任务回执、结果回填
```

- npm 提供版本化代码，不会自动部署服务、登记 App、创建数据库或授权用户。
- 服务端调用模型；浏览器不持上游凭据、不直连本轮 Appwrite 业务存储。CPU 工具不获取模型凭据、不产生模型调用费用。
- 当前文件、索引和画布引用由画布宿主的 Appwrite 云适配器保存。本轮联调使用 `grworkspace` 项目：`canvas_app_dev` 数据库和 `canvas_assets_v2` Storage 桶。工程大数据是 JSON 文件，画布仅保存路径、来源和版本；不把图片或凭据塞进工程 JSON。
- 本仓没有另建一套租户/用户/项目目录或独立图片业务数据库。可信身份、实例及项目授权由宿主提供；未来改存储归属需先定授权和映射合同。
- 当前实际开发环境为单维护者云存储联调模式，不等于真实双用户或生产租户隔离已验收。正式 MA 身份、逐用户模型授权/消费和生产私有桶仍需单独验证。

## npm 出口与 CLI

| 出口 | 用途 |
| --- | --- |
| 包根、`/server` | 登记元数据、动作 manifest、schema 和工程合同；保持 React-free |
| `/react` | `ImageCanvasCard`、工具组件及历史模式入口，由宿主提供 React |
| `/generation`、`/service` | 模型生成及 HTTP 服务适配 |
| `/backend` | 工具执行合同与后端实现 |
| `/authorization` | 授权适配 |

包内命令 `designai-image-service`、`designai-image-auth` 分别用于执行服务与显式本地设备授权。

**Agent 操作 CLI 是画布仓维护的独立包 `@ks-designai/canvas-cli@0.1.2`**，不是另建一个图片 CLI。它通过同一 HTTP API 发现/配置/调用图片 App，不独立保存业务数据。

## API / CLI 规则

| 动作 | 用途 |
| --- | --- |
| `image.create` | 创建来源卡，不调用模型 |
| `image.configure` | 修改提示词、模型、比例、分辨率、张数和参考图 |
| `image.generate` / `image.regenerate` | 显式生成/重新生成，保留已有结果 |
| `image.status` / `image.cancel` | 只读状态 / 取消本卡任务，不承诺供应商退款 |
| `image.tool` | 对当前卡片资源执行已配置工具 |
| `image.edit.read` / `image.edit.save` | 读取/保存可编辑样机工程 |

1. 先发现 manifest、读取实例状态和 `/tools`，不要把工具登记当作 Provider 可用。
2. 写动作必须带 `expectedRevision` 和稳定幂等键；网络结果不确定时先查回执，不能换键重试付费任务。
3. 工程保存额外带 `expectedEditRevision`，取自上次工程读/写结果。新画布版本不能替代工程版本；旧草稿冲突返回 409，重新读取后再处理。
4. 工程 `basePath` 使用服务返回的 canonical `sourcePath`。资源必须属于当前授权项目，拒绝临时 URL、其他项目路径和凭据；换源图片时拒绝套用旧工程。
5. `accepted` 仅代表受理；结果完整存储并回填后才 `succeeded`。不自动切换模型，不隐式重试付费调用。
6. 已完成工程回执先持久化归档再从画布裁剪，旧键仍可查询和重放，不覆盖最新工程。原生成动作的长期回执归档仍是待办，当前容量限制见合同。
7. 移动/删除/连线等沿用画布 API，禁止直接 PATCH 内部工程索引和回执。

```sh
canvas-cli request GET /api/apps/image
canvas-cli request GET /api/apps/image/instances/CANVAS_ID/tools
canvas-cli apps state image --instance CANVAS_ID
# crop.json: {"nodeId":"IMAGE_ID","kind":"crop","params":{"x":0,"y":0,"width":512,"height":512}}
canvas-cli apps call image image.tool --instance CANVAS_ID --body-file crop.json --expected-revision REV --idempotency-key crop-001
canvas-cli apps receipt image --instance CANVAS_ID --id crop-001
```

模型当前配置 ID 为 `designai-gpt-image-2` / `designai-gemini-image`；比例 `1:1/16:9/9:16/4:3/3:4`，分辨率 `2K/4K`，张数 1–4，提示词上限 7500 字符，参考图最多 16 个当前项目授权路径。具体模型实际可用性仍需上游与逐用户授权验收。

## 开发、打包与安装

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm build
pnpm test
mkdir -p artifacts
pnpm pack --pack-destination artifacts
```

先 build 再运行完整测试：部分后端测试会验证实际 `dist/` 产物。宿主安装实际 tarball：

```sh
pnpm add /实际产物目录/ks-designai-image-card-pack-0.8.0.tgz
```

**公司 registry 发布后**才能使用下式；本 README 不代表已经发布：

```sh
pnpm add @ks-designai/image-card-pack@0.8.0 --registry=https://npm.corp.kuaishou.com/
```

`editor/` 独立预览：`npm run editor:install` 后 `npm run editor:dev`，打开 `http://127.0.0.1:5178/excalidraw/component.html`。遵守其局部 AGENTS，不因此替换卡片或切换云项目。

## 本地联调与云部署边界

| 服务 | 本地地址 |
| --- | --- |
| 完整画布 Web | `http://127.0.0.1:17580/` |
| 宿主图片 App API | `http://127.0.0.1:17462/` |
| 图片执行适配器 | `http://127.0.0.1:17465/`，受服务 token 保护，不供浏览器直连 |

端口是开发配置，进程可能变化。云存储可用不代表执行器已上云；上线需部署对应服务并配置 endpoint、可信身份、权限和存储，不能让远端 MA 访问开发者电脑的 loopback。

本地设备/用户 SSO 仅供显式单用户开发，生产必须使用可信请求绑定的凭据提供器。MA 身份、Appwrite 会话、模型授权分别处理；禁止自报用户名作为可信身份、硬编码开发者授权、输出凭据或静默回退本地存储。详见 [生成授权](docs/GENERATION.md)。

## 验证证据与限制

本轮 0.8.0 已完成：

- 图片包 142 项测试、类型检查和构建；从 Git 干净导出、离线安装后再次通过。
- 宿主相关 8 个文件、47 项回归；服务端、workbench、Web 类型检查及 guard 通过。
- 11 项工具经真实 HTTP/任务/Appwrite 文件/画布回填/新缓存恢复；CPU 处理真实执行，模型响应使用 fixture，**本轮没有真实模型调用或扣费验收**。
- 原 CLI 创建、配置和重放；新增 CLI 工程读写、归档回执、160×120 裁剪结果下载和重放通过。
- 实际界面恢复云端贴图、旋转、CLI 读回坐标、刷新后恢复旋转；过期工程写入明确 409。

证据在 [本轮验收目录](docs/verification/mvp-api-20261022/README.md)。这不是整个 `editor/` 或所有外部服务的全量验收。历史 GPT 实际出图、Gemini 上游失败等记录见历史审计，不据此承诺当前模型可用性。

### 独立待办

- ComfyUI 及其他外部 GPU、分层/OCR、去背景、曲面等服务配置与真实效果验收。
- 正式 MA 登记/Agent 执行环境安装、逐用户鉴权与消费对账、生产私有桶、真实双用户隔离及 staging。
- 完整 `editor/` 的宿主协议和存储统一，仍独立于当前卡片接入。
- 无浏览器样机栅格化、矢量标注编辑 API、大工程历史/GC、原生成动作长期回执归档。

手动样机栅格化仍用原浏览器渲染器；工程 save/read 不等于无浏览器渲染。工程最多 8 层/128KiB，CPU 调整最多 800 万像素；dense-b 曲面暂不支持。未确认的裁剪/滑杆草稿不自动成为云工程，未完成的网络保存也不能保证即时关闭后恢复。

## 共同治理规则与文档入口

- 从最新 `main` 新建功能分支，通过 MR 合回 `main`；本次所有者明确授权本轮推送与合并，不修改默认分支或保护策略，不强推覆盖他人历史。
- 根包和 `editor/` 分别构建验收；共享能力改动检查双方消费者。外部宿主适配由本 App 完成，不修改 MA/DA 他人仓库迁就本包。
- TypeScript 新代码，后端不依赖前端私有实现；共享 DTO 保持纯合同。不得提交凭据、运行数据和依赖目录。
- `src/artifacts/` 是必须跟踪的源代码；根 `/artifacts/` 是打包输出，不能混淆忽略规则。
- 安装、模拟登记、正式登记、真实 Agent 调用、npm 发布和 staging 分开报告，不以构建或元数据代替真实业务验收。

开始开发先读 [AGENTS](AGENTS.md)、[App 合同](docs/APP_CONTRACT.md)、[MVP API](docs/MVP_API.md) 和 [共同集成说明](docs/INTEGRATION.md)。其他材料：[统一规范](docs/UNIFIED_APP_STANDARD.md)、[前端移植](docs/FRONTEND_TOOLS.md)、[后端工具](docs/BACKEND_TOOLS.md)、[完整编辑器迁移](docs/FULL_CANVAS_MIGRATION.md)、[历史审计](docs/APP_AUDIT.md)。
