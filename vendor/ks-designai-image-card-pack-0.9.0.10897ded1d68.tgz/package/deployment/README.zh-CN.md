# 独立生图后端部署

本入口运行 Image 自有业务服务，不承载画布。原图、结果、任务、配置、工程和回执使用 Image 独立数据库及私有桶；画布通过公开 API 保存资源引用与预览。历史 `designai-image-service` 是单用户模型执行入口，与本服务分别验收。正式 MA 登记、宿主组件安装、Agent 调用及上线行为各有独立验收，不能由镜像构建替代。

## 配置与构建

使用 Node 24、pnpm 10.33.2。源码发行应包含 `src/`、固定 `vendor/` 制品及锁文件；`Dockerfile.backend` 不复制运行数据、编辑器项目或凭据。先运行 `pnpm install --frozen-lockfile`、`pnpm build`、`pnpm test`，再执行：

```sh
docker build -f Dockerfile.backend -t designai-image-independent:release-candidate .
```

将 `backend.env.example` 复制到仓库外的受限配置文件，填写实际环境值。示例中的 `example.invalid` 是待替换配置，不是有效平台。`IMAGE_RUNTIME_ENV` 指向该文件；`IMAGE_APPWRITE_KEY_SOURCE`、`IMAGE_WRITE_GRANTS_SOURCE`、`IMAGE_MODEL_ADAPTER_SOURCE` 分别指向外部服务密钥、精确动作授权及可信模型适配模块文件。路径不写入发行包，文件逐个只读挂载，不能挂入维护者登录目录。

配置文件权限为600。密钥源文件放在权限700的外部父目录，通过平台 Secret 机制赋予容器 UID1000只读权限；使用本地文件挂载时，也必须确认 UID1000能读取挂入文件。不得直接挂载一个仅宿主用户可遍历的700目录给容器。可将源文件设为444并保持宿主父目录700，再逐文件只读挂载：宿主其他用户无法遍历父目录，容器只能读取指定文件。模型模块不应包含凭据；如需额外依赖，将它做成独立受控部署模块并提供完整依赖，不能依赖开发者源码检出。

```sh
docker compose -f deployment/compose.backend.yml config --quiet
docker compose -f deployment/compose.backend.yml up -d --build
```

集合和桶必须提前预置：`documentSecurity=true`、`fileSecurity=true`，集合/桶默认授权均为空。运行时只读检查这些策略，不修复现有 ACL、不建 schema、不初始化缺失 namespace。缺少配置或权限时启动失败。服务端 API Key 只授予本 App 所需数据库/文件读写，不能复用用户 SSO、维护会话或其他 App 的凭据。资源及权限审批由本仓负责人李鹏负责；共享平台访问由资源所属仓库负责人审批。

`IMAGE_APPWRITE_SINGLE_WRITER=true`、`IMAGE_REPLICAS=1` 必填。生产模式要求 Appwrite、MA authority 使用 HTTPS；本服务放在受控 HTTPS 网关后，网关保留 MA 身份请求头。`IMAGE_MA_APPLICATION_ID` 必须是平台实际登记的应用 ID；不能将画布应用实例的身份直接充当生图实例身份。

## 身份与模型授权

读写先使用公开 MA `/me` 与应用实例接口回查当前 SSO、租户及实例，然后核对该实例属于配置的生图应用。业务路径再检查完整租户/业务/应用/实例/Provider作用域。`IMAGE_WRITE_GRANTS_FILE` 是当前服务端精确动作委派配置，仅包含已验证身份的权限范围，不建立新的用户目录；无授权默认为只读。动作列表不得使用通配符。例如：

```json
[{"teamId":"approved-team","bizId":"approved-biz","userId":"approved-user","applicationId":"registered-image-app","applicationInstanceId":"approved-instance","actions":["image.create","image.import","image.configure","image.generate","image.regenerate","image.tool","image.edit.save","image.cancel","image.archive"]}]
```

MA 访问权限与模型授权分别验证。默认 `IMAGE_MODELS=enabled`，须配置 `IMAGE_MODEL_ADAPTER`，该服务端 JavaScript 模块导出：

```ts
export async function credentials(caller: Readonly<ImageCaller>): Promise<CredentialProvider>;
export async function providers(caller: Readonly<ImageCaller>): Promise<ImageToolProviders>; // 可选
```

模块由部署方安装在只读服务目录，并通过已批准的逐用户授权服务返回当前调用者的模型凭据。不能接受浏览器声明的用户名，不能借用维护者登录态，不能直接转发 MA SSO 作为模型凭据。凭据仅存在于请求执行内存，不写入任务或文件。外部 GPU/分层/曲面 Provider 可由 `providers` 明确注入；未配置的工具必须报告不可用。

若部署仅用于 CPU/矢量工具，必须显式设 `IMAGE_MODELS=disabled`；此时模型操作不可用，不能报告双模型验收通过。浏览器 Origin 必须逐项精确配置，不能使用 `*`。

## 生命周期与恢复

服务取得独占云端写锁后加载状态，校验业务索引并将旧 queued/running 任务标记为 interrupted，然后才监听请求。重启不会自动执行有成本任务。队列与并发有界；归档前必须结束或取消活动任务。正常 SIGTERM 先停止接入、取消执行、刷新云端状态，再只释放自身锁。

此锁没有租约接管或分布式 fencing。升级采用停止旧实例、确认关闭、再启动新实例，不能滚动重叠。异常退出、持久写失败或关停超时可能留下锁，新实例会拒绝启动；运维必须先确认旧进程/容器/副本已停止，再检查云端状态并显式处理锁。不要定时自动删除或凭“过期时间”抢占。

`GET /api/health` 检查进程；`GET /api/ready` 检查状态加载与持久写屏障，发生持久化故障后返回503。健康探针不能替代 MA/模型授权检查。业务 API、CLI、返回字节均走相同作用域鉴权，私有文件不返回公开桶地址。

## 部署验收

至少保存：固定源码/包/镜像哈希，容器实际启动及只读文件系统，真实云端写入与下载解码，双进程拒绝，SIGTERM与空缓存重启，任务取消/失败/中断恢复，幂等与版本拒绝，租户/实例隔离及撤权，双模型各一次真实结果，已安装CLI调用。正式 MA 登记及实际 Agent 工具调用需另附宿主侧证据。

显式开发维护测试可使用 `designai-image-app-server --maintenance-prefs /absolute/private/prefs.json`，仅限非生产、`127.0.0.1`监听，与服务端API Key互斥。此方式不进入生产部署，不作为真实用户SSO或模型broker验收。

## 文件上传 profile

本后台固定采用经过公司平台实测的分块方式：每块为 **5,000,000 字节（十进制 5MB）**，不是 5MiB；Content-Range、后续 X-Appwrite-ID、完整计数和私有权限均校验。特定合法 PNG 在旧 5MiB 路径的末块失败，同一原件改用精确 5MB 分块后读回字节一致。完整 multipart 请求另有网关大小限制，不能因为小文件 single 上传成功就宣称支持桶内的全部容量。低层 client 保留 single 供显式适配，不作为本后台的运行 profile。原件不重新编码，不采用 gzip 封装，也不迁移既有资产索引。

## 首次预置与 namespace

资源合同为同目录 appwrite-schema.json（声明规范，不是 Appwrite 官方导出文件）。资源负责人先在批准的 project 中建立独立 database、私有 app_runtime_state collection、属性/namespace 索引与私有 bucket，等待属性和索引全部 available；不要修改其他 App 或既有开发库的 ACL。生产示例使用单独 staging 资源，不能把测试资源存在当成生产资源已分配。

Schema 就绪且服务尚未启动时，用部署镜像执行一次明确的 namespace 初始化；这只创建缺失 manifest，不创建 schema、不覆盖既有业务行。配置/文件挂载仍由部署 compose 提供，命令不打印密钥；若使用冻结交付目录，将命令中的 compose 路径替换为 compose.release.yml：

```sh
docker compose --env-file /absolute/private/deployment.env -f deployment/compose.backend.yml run --rm --no-deps --entrypoint node image --input-type=module -e '
import {readFile} from "node:fs/promises";
import {ImageAppwriteClient} from "./dist/app-backend/appwrite-client.js";
import {AppwriteJsonState} from "@ks-designai/app-cloud-state";
const e=process.env;
const client=new ImageAppwriteClient({endpoint:e.IMAGE_APPWRITE_ENDPOINT,projectId:e.IMAGE_APPWRITE_PROJECT_ID,apiKey:(await readFile(e.IMAGE_APPWRITE_API_KEY_FILE,"utf8")).trim(),uploadMode:"chunked"});
const state=new AppwriteJsonState({client,databaseId:e.IMAGE_APPWRITE_DATABASE_ID,collectionId:e.IMAGE_APPWRITE_RUNTIME_COLLECTION_ID,namespace:e.IMAGE_RUNTIME_NAMESPACE,singleWriter:true,initialize:true});
await state.ready; await state.flush(); console.log("Image namespace ready");'
```

运行时缺少 schema、权限或 manifest 仍会拒绝启动，不会隐式执行这一步。其他部署编排工具用同样镜像/环境和明确命令运行一次性任务；不要给正常应用扩大 schema 管理权限。

## 模型尺寸档位

`resolution=4K` 是既有协议的高清档标识，不统一承诺每条边为 4096 像素。GPT 档位映射：1:1 为 2880×2880、16:9 为 3840×2160、9:16 为 2160×3840、3:4 为 2448×3264、4:3 为 3264×2448；Gemini 方图 4K 为 4096×4096。验收以实际解码后的宽高为准，不对原始产物做插值伪装。
